import { Link } from "react-router-dom";

function Dashboard(){
    return(
        <div>
            <h1>Dashboard</h1>
            GameOver

            <Link to="/" element={<div><h1>Home</h1></div>}/>
        </div>
    )
}

export default Dashboard