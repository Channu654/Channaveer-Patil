// Write code for Registration context
