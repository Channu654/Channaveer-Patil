// write reducer for the registartion reducer
